function soma(){
    var n1 = parseInt(prompt("Digite um valor: "));
    var n2 = parseInt(prompt("Digite outro valor: "));
    var resultado = n1 + n2;
    alert("Resultado é: " + resultado);
}

function subtracao(){
    var n1 = parseInt(prompt("Digite um valor: "));
    var n2 = parseInt(prompt("Digite outro valor: "));
    var resultado = n1 - n2;
    alert("Resultado é: " + resultado);
}

function multiplicacao(){
    var n1 = parseInt(prompt("Digite um valor: "));
    var n2 = parseInt(prompt("Digite outro valor: "));
    var resultado = n1 * n2;
    alert("Resultado é: " + resultado);
}

function divisao(){
    var n1 = parseInt(prompt("Digite um valor: "));
    var n2 = parseInt(prompt("Digite outro valor: "));
    var resultado = n1 / n2;
    alert("Resultado é: " + resultado);
}